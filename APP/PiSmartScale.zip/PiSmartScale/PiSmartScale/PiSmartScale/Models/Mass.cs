﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PiSmartScale.Models
{
    class Mass
    {
        public string date_time { get; set; }
        public string measurement { get; set; }
    }
}