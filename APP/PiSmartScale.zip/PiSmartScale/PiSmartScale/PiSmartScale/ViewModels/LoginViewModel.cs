﻿using PiSmartScale.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

using System.Net.Http;
using System.Threading.Tasks;
using System.Diagnostics;
using PiSmartScale.Models;

namespace PiSmartScale.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        public string usernameEntry { get; set; } = string.Empty;
        public string passwordEntry { get; set; } = string.Empty;
        public string loginOutLabel { get; set; } = string.Empty;
        public Command LoginCommand { get; }
        public Command RegisterCommand { get; }


        public LoginViewModel()
        {
            LoginCommand = new Command(LoginUser);
            RegisterCommand = new Command(RegisterUser);
        }

        public async Task<string> VerifyLogin(string jsonData)
        {
            string result = string.Empty;
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://192.168.50.207:1337");
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            try
            {
                HttpResponseMessage response = await client.PostAsync("/users/login", content);
                result = await response.Content.ReadAsStringAsync();
                client.Dispose();
            }
            catch (Exception ex)
            {
                loginOutLabel = "Connection Error you or the server might be down";
                OnPropertyChanged(nameof(loginOutLabel));
                return "Failure";
            }

            if (result == "Success")
                return "Success";
            else
            {
                loginOutLabel = "Failed To Login Please Try again";
                OnPropertyChanged(nameof(loginOutLabel));
                return "Failure";
            }
        }

        public async Task<string> VerifyRegister(string jsonData)
        {
            string result = string.Empty;
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://192.168.50.207:1337");
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            try
            {
                HttpResponseMessage response = await client.PostAsync("/users/create", content);
                result = await response.Content.ReadAsStringAsync();
                client.Dispose();
            }
            catch (Exception ex)
            {
                loginOutLabel = "Connection Error you or the server might be down";
                OnPropertyChanged(nameof(loginOutLabel));
                return "Error";
            }

            if (result == "Success")
                return "Success";
            else
            {
                loginOutLabel = "Username Taken or Password Invalid";
                OnPropertyChanged(nameof(loginOutLabel));
                return "Failure";
            }
        }

        private async void LoginUser()
        {
            if (usernameEntry == string.Empty || passwordEntry == string.Empty)
                return;
            else
            {
                string preparedJSON = $"{{ \"name\" : \"{usernameEntry}\", \"password\" : \"{passwordEntry}\" }}";
                Task<string> theTask = VerifyLogin(preparedJSON);

               
                string rvalue = await theTask;
                if (rvalue == "Success")
                {
                    User.name = usernameEntry;
                    User.password = passwordEntry;
                    User.loggedIn = true;

                    Application.Current.MainPage = new AppShell();
                    await Shell.Current.GoToAsync("//main");

                    Debug.WriteLine("User Logged In");
                }
            }
        }

        private async void RegisterUser()
        {
            if (usernameEntry == string.Empty || passwordEntry == string.Empty)
                return;
            else
            {
                string preparedJSON = $"{{ \"name\" : \"{usernameEntry}\", \"password\" : \"{passwordEntry}\" }}";
                Task<string> theTask = VerifyRegister(preparedJSON);
                string rvalue = await theTask;
                if (rvalue == "Success")
                {
                    LoginUser();

                    //Update View
                    Debug.WriteLine("User Registered");
                }
            }
        }
    }
}
