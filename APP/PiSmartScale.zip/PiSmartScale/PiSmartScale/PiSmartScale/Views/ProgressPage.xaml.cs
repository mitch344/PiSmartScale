﻿using PiSmartScale.ViewModels;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Microcharts;
using SkiaSharp;

namespace PiSmartScale.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]

    public partial class ProgressPage : ContentPage
    {
        ProgressViewModel _viewModel;
        public ProgressPage()
        {
            InitializeComponent();
            _viewModel = new ProgressViewModel();
            BindingContext = _viewModel;
        }

        protected async override void OnAppearing()
        {
            Task loadViewsTask = _viewModel.loadViews();
            await loadViewsTask;
            chartView.Chart = new LineChart { Entries = _viewModel.elements, LineSize = 8, LabelTextSize = 30, PointSize = 18, PointMode = PointMode.Circle, BackgroundColor = SKColor.Parse("eeeeee") };
            base.OnAppearing();
        }
    }
}