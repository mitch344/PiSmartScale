﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PiSmartScale.Models
{
    public static class User
    {
        public static string name;
        public static string password;
        public static bool loggedIn = false;
    }
}