﻿using System;
using System.Collections.Generic;
using PiSmartScale.ViewModels;
using PiSmartScale.Views;
using Xamarin.Forms;

namespace PiSmartScale
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(ProgressPage), typeof(ProgressPage));
        }

    }
}
