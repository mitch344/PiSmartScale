﻿using PiSmartScale.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microcharts;
using SkiaSharp;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Input;
using Xamarin.Forms;

/*
 * Optimize by getting 999 and then for loop for the first five so you load only onces
 */

namespace PiSmartScale.ViewModels
{
    class ProgressViewModel : BaseViewModel
    {
        public Microcharts.ChartEntry[] elements { set; get; }
        public ObservableCollection<Mass> Items { set; get; }

        private int max_graph_num = 14; //max number of plotted on graph view

        public ProgressViewModel()
        {
            Items = new ObservableCollection<Mass>();
        }

        public async Task loadViews()
        {
            Items.Clear();

            string preparedJSON = $"{{ \"name\" : \"{User.name}\", \"password\" : \"{User.password}\", \"mass\" : 999 }}";
            Task<string> getMassDataTask = getMassData(preparedJSON);
            string returnedJSON = await getMassDataTask;

            List<Mass> returnedMass = JsonConvert.DeserializeObject<List<Mass>>(returnedJSON);
            List<ChartEntry> temp = new List<ChartEntry>();

            int graphNum = 0;
            foreach (Mass item in returnedMass)
            {
                item.measurement = Math.Round(double.Parse(item.measurement), 2).ToString();

                TimeZoneInfo cst = TimeZoneInfo.Local;
                DateTime utc = DateTime.Parse(item.date_time);
                string month = TimeZoneInfo.ConvertTimeFromUtc(utc, cst).Month.ToString();
                string day = TimeZoneInfo.ConvertTimeFromUtc(utc, cst).Day.ToString();
                item.date_time = TimeZoneInfo.ConvertTimeFromUtc(utc, cst).ToShortDateString().ToString() + " " +
                    TimeZoneInfo.ConvertTimeFromUtc(utc, cst).ToShortTimeString().ToString();

                if (graphNum < max_graph_num)
                {
                    ChartEntry addItem = new ChartEntry(float.Parse(item.measurement));
                    addItem.Label = month + "/" + day;
                    addItem.ValueLabel = item.measurement;
                    addItem.Color = SKColor.Parse("#2196F3");
                    temp.Add(addItem);
                    graphNum++;
                }
                Items.Add(item);
            }
            var reversGraph = temp.ToArray().Reverse();
            elements = reversGraph.ToArray();
        }

        public async Task<string> getMassData(string jsonData)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://192.168.50.207:1337");
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            try
            {
                HttpResponseMessage response = await client.PostAsync("/users/massdata", content);
                string result = await response.Content.ReadAsStringAsync();
                client.Dispose();
                return result;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
    }
}
